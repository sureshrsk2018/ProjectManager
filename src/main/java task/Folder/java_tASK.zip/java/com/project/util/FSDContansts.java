package com.project.util;

public  class FSDContansts {
	public static final String APPLICATION_JSON = "application/json";
}
